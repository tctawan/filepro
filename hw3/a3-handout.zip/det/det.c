#include <stdio.h>
#include <stdlib.h>
#include <string.h>

double compute_det(int **a, int n) {
  // implement this
  return 0.0;
}

/*
TEST: ./det < det.in
OUTPUT:
-105.00000
*/
int main(void) {
  // implement this
}
