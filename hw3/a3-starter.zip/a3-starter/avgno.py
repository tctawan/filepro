def robust_avg(lst):
    """

    >>> round(robust_avg([3, 1, 2, 5, 9, 11, 4]), 4)
    4.6
    """
    return ___


###########################################################################
# Please don't mind me living down here. I provide some initial testing for
# your code. Run me (e.g., using the run button in Spyder).
###########################################################################
# Simple Tests
###########################################################################
if __name__ == "__main__":
    import doctest
    doctest.testmod()
###########################################################################
