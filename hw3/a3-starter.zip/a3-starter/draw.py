def triangle(k):
    """

    >>> triangle(1)
    *
    >>> triangle(3)
    ##*##
    #***#
    *****

    """
    print()

def diamond(k):
    """

    >>> diamond(2)
    ##*##
    #***#
    #***#
    ##*##
    >>> diamond(4)
    ####*####
    ###***###
    ##*****##
    #*******#
    #*******#
    ##*****##
    ###***###
    ####*####

    """
    print


###########################################################################
# Please don't mind me living down here. I provide some initial testing for
# your code. Run me (e.g., using the run button in Spyder).
###########################################################################
# Simple Tests
###########################################################################
if __name__ == "__main__":
    import doctest
    doctest.testmod()
###########################################################################
