def sumOfDigitsSquared(n):
    """

    >>> sumOfDigitsSquared(7)
    49
    >>> sumOfDigitsSquared(145)
    42
    >>> sumOfDigitsSquared(199)
    163
    """
    return ___

def isHappy(n):
    """

    >>> isHappy(100)
    True
    >>> isHappy(111)
    False
    >>> isHappy(1234)
    False
    >>> isHappy(989)
    True
    """
    return ___

def kThHappy(k):
    """

    >>> kThHappy(1)
    1
    >>> kThHappy(3)
    10
    >>> kThHappy(11)
    49
    >>> kThHappy(19)
    97
    """
    return ___


###########################################################################
# Please don't mind me living down here. I provide some initial testing for
# your code. Run me (e.g., using the run button in Spyder).
###########################################################################
# Simple Tests
###########################################################################
if __name__ == "__main__":
    import doctest
    doctest.testmod()
###########################################################################
