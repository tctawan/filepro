def allMultiplesOfK(k, lst):
    """

    >>> allMultiplesOfK(4, [1,10,20])
    False
    >>> allMultiplesOfK(3, [81,3,24])
    True
    >>> allMultiplesOfK(11, [])
    True
    """
    return ___


###########################################################################
# Please don't mind me living down here. I provide some initial testing for
# your code. Run me (e.g., using the run button in Spyder).
###########################################################################
# Simple Tests
###########################################################################
if __name__ == "__main__":
    import doctest
    doctest.testmod()
###########################################################################
